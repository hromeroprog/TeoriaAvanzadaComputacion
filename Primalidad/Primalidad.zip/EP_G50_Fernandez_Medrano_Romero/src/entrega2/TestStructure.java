package entrega2;

public class TestStructure {
    public long time;
    boolean isPrime;

    public TestStructure(long time, boolean isPrime) {
        this.time = time;
        this.isPrime = isPrime;
    }
}
