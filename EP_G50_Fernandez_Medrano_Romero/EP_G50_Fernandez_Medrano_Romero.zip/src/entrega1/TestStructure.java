package entrega1;
import java.math.BigInteger;

public class TestStructure {
	public long time;
	BigInteger result;
	
	public TestStructure(long time, BigInteger result) {
		this.time = time;
		this.result = result;
	}
}
