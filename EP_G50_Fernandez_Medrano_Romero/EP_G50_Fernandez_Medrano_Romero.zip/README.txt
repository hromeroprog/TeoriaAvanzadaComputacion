Este archivo comprimido contiene los documentos del ejercicio introductorio de Teoría Avanzada de Computación de la UC3M
realizado por Irene Fernández Robledo, Maribel Medrano Fernández y Hugo Romero Rico.
	
	-El archivo memoria.pdf es la memoria que documenta la práctica.

	-El código fuente en java de la práctica se encuentra en la carpeta src, organizado por carpetas cada uno de los hitos.
	
	-La carpeta primality_files recoge los archivos csv relativos a los tests de primalidad realizados en el HITO 1, claisificados por 
	por el algoritmo utilizado para la evaluación (inicio de nombre del archivo) y por si se le pasaban solo números primos
	aleatorios al algoritmo (fin de nombre de archivo con _primes) o si se le pasaba cualquier número aleatorio (fin del
	nombre de archivo con _comp).
	
	-La carpeta reduction_files contiene dos archivos csv, relativos al HITO 2, con el resultado del algoritmo de reducción
	también clasificados por si se le pasaban solo números primos aleatorios al algoritmo (fin de nombre de archivo con _primes)
	 o si se le pasaba cualquier número aleatorio (fin del nombre de archivo con _comp).
	
	-La carpeta hito3_files contiene un único archivo csv relativo a la prueba pedida en el HITO 3 de la práctica.

	-Los archivos:
		SacarGráficas.py
		Graficas para el numero de digitos.py
		Graficacion Hito 2.py
	Contienen los scripts en python utilizados para la graficación del proyecto a partir de los ficheros csv.
	